import os
import json
from PyQt6.QtCore import QSettings, QByteArray

from paths import config_path


class LanguageManager:
    """Gestor de traducción desde un archivo JSON."""

    def __init__(self, filepath: str = None):
        self.filepath = filepath or config_path("translations.json")
        self.current_lang = "es"
        self.translations = {}
        self.load_translations()

    def load_translations(self):
        if not os.path.exists(self.filepath):
            self._create_default_json()
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                self.translations = json.load(f)
        except Exception as e:
            print(f"Error al cargar traducciones: {e}")

    def _create_default_json(self):
        default_data = {
            "en": {
                "window_title": "Multi PSU Controller",
                "add_psu": "➕ Add Power Supply",
                "max_psu_warning": "Maximum limit of 6 power supplies reached.",
                "psu_title": "Power Supply #",
                "lang_label": "Language:",
                "group_conn": "Connection",
                "lbl_profile": "Profile:",
                "lbl_channel": "Channel:",
                "lbl_ip": "IP:",
                "lbl_port": "Port:",
                "lbl_mode": "Mode:",
                "btn_connect": "Connect",
                "btn_disconnect": "Disconnect",
                "status_connected": "CONNECTED",
                "status_disconnected": "DISCONNECTED",
                "status_error": "ERROR",
                "group_ctrl": "Output Settings",
                "lbl_v": "Voltage (V):",
                "lbl_i": "Current Limit (A):",
                "btn_set_v": "Set V",
                "btn_set_i": "Set I",
                "btn_enable_out": "ENABLE OUTPUT (OFF)",
                "btn_disable_out": "DISABLE OUTPUT (ON)",
                "group_log": "SCPI Console",
                "group_readout": "Real-Time Telemetry",
                "lbl_v_head": "VOLTAGE",
                "lbl_i_head": "CURRENT",
                "lbl_p_head": "POWER",
                "plot_title": "Voltage History V (#{index})",
                "log_dock_title": "Log Event",
                "group_events": "Event Log",
                "btn_clear_log": "Clear",
                "evt_app_started": "Application started v{version}",
                "evt_session_restored": "Previous session restored ({count} sources)",
                "evt_lang_changed": "Language changed to English",
                "menu_config": "Config",
                "menu_language": "Language",
                "act_open_config": "Open configuration folder",
                "menu_view": "View",
                "act_view_console": "SCPI Console",
                "act_view_log": "Event Log",
                "act_equalize": "Equalize panels",
                "menu_help": "Help",
                "act_about": "About",
                "act_about_qt": "About Qt",
                "about_title": "About",
                "about_text": "<b>{app}</b><br>Version {version}<br><br>Multi-instrument SCPI controller for power supplies.<br>Qt {qt} · PyQt {pyqt}<br><br>© Skytrac",
                "add_eload": "➕ Add ELoad",
                "eload_title": "ELoad #",
                "max_eload_warning": "Maximum limit of 6 electronic loads reached.",
                "group_ctrl_load": "Load Settings",
                "lbl_load_mode": "Mode:",
                "lbl_level": "Level",
                "btn_set_level": "Set",
                "btn_enable_in": "ENABLE INPUT (OFF)",
                "btn_disable_in": "DISABLE INPUT (ON)",
                "mode_CC": "CC - Constant Current",
                "mode_CV": "CV - Constant Voltage",
                "mode_CR": "CR - Constant Resistance",
                "mode_CP": "CP - Constant Power",
                "evt_instr_added": "{name} added",
                "evt_instr_closed": "{name} closed",
                "lbl_filter": "Instrument:",
                "filter_all": "All",
                "tip_record": "Record telemetry",
                "tip_pause": "Pause / resume recording",
                "tip_stop": "Stop recording",
                "tip_export": "Export the finished recording (CSV)",
                "btn_export": "Export",
                "rec_status_rec": "REC",
                "rec_status_paused": "PAUSED",
                "rec_samples": "samples",
                "evt_rec_started": "Recording started: {file}",
                "evt_rec_resumed": "Recording resumed",
                "evt_rec_paused": "Recording paused",
                "evt_rec_stopped": "Recording stopped ({samples} samples): {file}",
                "evt_rec_exported": "Data exported to {file}",
                "rec_no_data": "Stop a recording with data before exporting.",
                "rec_no_instruments": "No instrument connected: data will be recorded once they connect.",
                "export_dialog_title": "Export telemetry",
                "menu_theme": "Themes",
                "theme_dark": "Dark Theme",
                "theme_light": "Light Theme",
                "theme_high_contrast": "High Contrast",
                "evt_theme_changed": "Theme changed: {name}",
                "status_connecting": "CONNECTING...",
                "status_disconnecting": "DISCONNECTING...",
                "btn_cancel": "Cancel"
            },
            "es": {
                "window_title": "Controlador Multi Fuentes",
                "add_psu": "➕ Agregar Fuente",
                "max_psu_warning": "Se ha alcanzado el límite máximo de 6 fuentes.",
                "psu_title": "Fuente #",
                "lang_label": "Idioma:",
                "group_conn": "Conexión",
                "lbl_profile": "Perfil:",
                "lbl_channel": "Canal:",
                "lbl_ip": "IP:",
                "lbl_port": "Puerto:",
                "lbl_mode": "Modo:",
                "btn_connect": "Conectar",
                "btn_disconnect": "Desconectar",
                "status_connected": "CONECTADO",
                "status_disconnected": "DESCONECTADO",
                "status_error": "ERROR",
                "group_ctrl": "Ajustes de Salida",
                "lbl_v": "Voltaje (V):",
                "lbl_i": "Límite I (A):",
                "btn_set_v": "Set V",
                "btn_set_i": "Set I",
                "btn_enable_out": "HABILITAR SALIDA (OFF)",
                "btn_disable_out": "DESHABILITAR SALIDA (ON)",
                "group_log": "Consola SCPI",
                "group_readout": "Telemetría en Tiempo Real",
                "lbl_v_head": "VOLTAJE",
                "lbl_i_head": "CORRIENTE",
                "lbl_p_head": "POTENCIA",
                "plot_title": "Histórico de Voltaje V (#{index})",
                "log_dock_title": "Log Event",
                "group_events": "Registro de Eventos",
                "btn_clear_log": "Limpiar",
                "evt_app_started": "Aplicación iniciada v{version}",
                "evt_session_restored": "Sesión anterior restaurada ({count} fuentes)",
                "evt_lang_changed": "Idioma cambiado a Español",
                "menu_config": "Config",
                "menu_language": "Idioma",
                "act_open_config": "Abrir carpeta de configuración",
                "menu_view": "Ver",
                "act_view_console": "Consola SCPI",
                "act_view_log": "Event Log",
                "act_equalize": "Igualar paneles",
                "menu_help": "Ayuda",
                "act_about": "Acerca de",
                "act_about_qt": "Acerca de Qt",
                "about_title": "Acerca de",
                "about_text": "<b>{app}</b><br>Versión {version}<br><br>Controlador SCPI multi-instrumento para fuentes de alimentación.<br>Qt {qt} · PyQt {pyqt}<br><br>© Skytrac",
                "add_eload": "➕ Agregar ELoad",
                "eload_title": "ELoad #",
                "max_eload_warning": "Se ha alcanzado el límite máximo de 6 cargas electrónicas.",
                "group_ctrl_load": "Ajustes de Carga",
                "lbl_load_mode": "Modo:",
                "lbl_level": "Nivel",
                "btn_set_level": "Set",
                "btn_enable_in": "HABILITAR ENTRADA (OFF)",
                "btn_disable_in": "DESHABILITAR ENTRADA (ON)",
                "mode_CC": "CC - Corriente Constante",
                "mode_CV": "CV - Voltaje Constante",
                "mode_CR": "CR - Resistencia Constante",
                "mode_CP": "CP - Potencia Constante",
                "evt_instr_added": "{name} agregada",
                "evt_instr_closed": "{name} cerrada",
                "lbl_filter": "Instrumento:",
                "filter_all": "Todos",
                "tip_record": "Grabar telemetría",
                "tip_pause": "Pausar / reanudar grabación",
                "tip_stop": "Detener grabación",
                "tip_export": "Exportar la grabación finalizada (CSV)",
                "btn_export": "Exportar",
                "rec_status_rec": "REC",
                "rec_status_paused": "PAUSA",
                "rec_samples": "muestras",
                "evt_rec_started": "Grabación iniciada: {file}",
                "evt_rec_resumed": "Grabación reanudada",
                "evt_rec_paused": "Grabación en pausa",
                "evt_rec_stopped": "Grabación detenida ({samples} muestras): {file}",
                "evt_rec_exported": "Datos exportados a {file}",
                "rec_no_data": "Detén una grabación con datos antes de exportar.",
                "rec_no_instruments": "Ningún instrumento conectado: se grabarán datos cuando se conecten.",
                "export_dialog_title": "Exportar telemetría",
                "menu_theme": "Temas",
                "theme_dark": "Dark Theme",
                "theme_light": "Light Theme",
                "theme_high_contrast": "High Contrast",
                "evt_theme_changed": "Tema cambiado: {name}",
                "status_connecting": "CONECTANDO...",
                "status_disconnecting": "DESCONECTANDO...",
                "btn_cancel": "Cancelar"
            },
            "fr": {
                "window_title": "Contrôleur Multi-Alimentation",
                "add_psu": "➕ Ajouter Alimentation",
                "max_psu_warning": "Limite maximale de 6 alimentations atteinte.",
                "psu_title": "Alimentation #",
                "lang_label": "Langue:",
                "group_conn": "Connexion",
                "lbl_profile": "Profil:",
                "lbl_channel": "Canal:",
                "lbl_ip": "IP:",
                "lbl_port": "Port:",
                "lbl_mode": "Mode:",
                "btn_connect": "Connecter",
                "btn_disconnect": "Déconnecter",
                "status_connected": "CONNECTÉ",
                "status_disconnected": "DÉCONNECTÉ",
                "status_error": "ERREUR",
                "group_ctrl": "Réglages de Sortie",
                "lbl_v": "Tension (V):",
                "lbl_i": "Limite I (A):",
                "btn_set_v": "Régler V",
                "btn_set_i": "Régler I",
                "btn_enable_out": "ACTIVER SORTIE (OFF)",
                "btn_disable_out": "DÉSACTIVER SORTIE (ON)",
                "group_log": "Console SCPI",
                "group_readout": "Télémétrie en Temps Réel",
                "lbl_v_head": "TENSION",
                "lbl_i_head": "COURANT",
                "lbl_p_head": "PUISSANCE",
                "plot_title": "Historique de Tension V (#{index})",
                "log_dock_title": "Log Event",
                "group_events": "Journal des Événements",
                "btn_clear_log": "Effacer",
                "evt_app_started": "Application démarrée v{version}",
                "evt_session_restored": "Session précédente restaurée ({count} sources)",
                "evt_lang_changed": "Langue changée en Français",
                "menu_config": "Config",
                "menu_language": "Langue",
                "act_open_config": "Ouvrir le dossier de configuration",
                "menu_view": "Affichage",
                "act_view_console": "Console SCPI",
                "act_view_log": "Journal d'événements",
                "act_equalize": "Égaliser les panneaux",
                "menu_help": "Aide",
                "act_about": "À propos",
                "act_about_qt": "À propos de Qt",
                "about_title": "À propos",
                "about_text": "<b>{app}</b><br>Version {version}<br><br>Contrôleur SCPI multi-instrument pour alimentations.<br>Qt {qt} · PyQt {pyqt}<br><br>© Skytrac",
                "add_eload": "➕ Ajouter ELoad",
                "eload_title": "ELoad #",
                "max_eload_warning": "Limite maximale de 6 charges électroniques atteinte.",
                "group_ctrl_load": "Réglages de Charge",
                "lbl_load_mode": "Mode:",
                "lbl_level": "Niveau",
                "btn_set_level": "Régler",
                "btn_enable_in": "ACTIVER ENTRÉE (OFF)",
                "btn_disable_in": "DÉSACTIVER ENTRÉE (ON)",
                "mode_CC": "CC - Courant Constant",
                "mode_CV": "CV - Tension Constante",
                "mode_CR": "CR - Résistance Constante",
                "mode_CP": "CP - Puissance Constante",
                "evt_instr_added": "{name} ajoutée",
                "evt_instr_closed": "{name} fermée",
                "lbl_filter": "Instrument :",
                "filter_all": "Tous",
                "tip_record": "Enregistrer la télémétrie",
                "tip_pause": "Pause / reprise",
                "tip_stop": "Arrêter l'enregistrement",
                "tip_export": "Exporter l'enregistrement terminé (CSV)",
                "btn_export": "Exporter",
                "rec_status_rec": "REC",
                "rec_status_paused": "PAUSE",
                "rec_samples": "échantillons",
                "evt_rec_started": "Enregistrement démarré : {file}",
                "evt_rec_resumed": "Enregistrement repris",
                "evt_rec_paused": "Enregistrement en pause",
                "evt_rec_stopped": "Enregistrement arrêté ({samples} échantillons) : {file}",
                "evt_rec_exported": "Données exportées vers {file}",
                "rec_no_data": "Arrêtez un enregistrement contenant des données avant d'exporter.",
                "rec_no_instruments": "Aucun instrument connecté : les données seront enregistrées à leur connexion.",
                "export_dialog_title": "Exporter la télémétrie",
                "menu_theme": "Thèmes",
                "theme_dark": "Thème sombre",
                "theme_light": "Thème clair",
                "theme_high_contrast": "Contraste élevé",
                "evt_theme_changed": "Thème changé : {name}",
                "status_connecting": "CONNEXION...",
                "status_disconnecting": "DÉCONNEXION...",
                "btn_cancel": "Annuler"
            }
        }
        with open(self.filepath, 'w', encoding='utf-8') as f:
            json.dump(default_data, f, indent=4, ensure_ascii=False)

    def get(self, key: str, **kwargs) -> str:
        lang_dict = self.translations.get(self.current_lang, self.translations.get("en", {}))
        text = lang_dict.get(key, key)
        if kwargs:
            text = text.format(**kwargs)
        return text


class AppConfigManager:
    """Maneja la carga y guardado de las configuraciones del sistema y sesión (config/session.ini)."""

    def __init__(self, filepath: str = None):
        self.filepath = filepath or config_path("session.ini", seed=False)
        self.settings = QSettings(self.filepath, QSettings.Format.IniFormat)

    def get_language(self, default="es") -> str:
        return self.settings.value("language", default)

    def save_language(self, lang: str):
        self.settings.setValue("language", lang)

    def get_value(self, key: str, default=None):
        return self.settings.value(key, default)

    def set_value(self, key: str, value):
        self.settings.setValue(key, value)

    def get_console_visible(self, default: bool = False) -> bool:
        return str(self.settings.value("scpi_console_visible", default)).lower() in ("true", "1")

    def save_console_visible(self, visible: bool):
        self.settings.setValue("scpi_console_visible", visible)

    def save_session(self, language: str, geometry: QByteArray, window_state: QByteArray, psu_states: list,
                     screen_signature: str = ""):
        """Guarda la geometría de la ventana, la disposición de los paneles y el estado de los instrumentos."""
        self.settings.setValue("language", language)
        self.settings.setValue("screen_signature", screen_signature)
        self.settings.setValue("geometry", geometry)
        self.settings.setValue("windowState", window_state)
        self.settings.setValue("psu_count", len(psu_states))
        self.settings.setValue("psu_states_json", json.dumps(psu_states))

    def load_session(self) -> dict | None:
        """Carga la sesión previa si existe."""
        psu_states_json = self.settings.value("psu_states_json", None)
        if not psu_states_json:
            return None

        try:
            psu_states = json.loads(psu_states_json)
            if not psu_states:
                return None

            return {
                "geometry": self.settings.value("geometry"),
                "windowState": self.settings.value("windowState"),
                "screen_signature": self.settings.value("screen_signature", ""),
                "psu_states": psu_states
            }
        except Exception as e:
            print(f"Error al cargar la sesión guardada: {e}")
            return None

    def sync(self):
        self.settings.sync()
